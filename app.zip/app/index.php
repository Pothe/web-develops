<?php
require_once 'includes/functions.php';
requireLogin();
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>smart System control</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="app-wrap">

  <!-- ── SIDEBAR ────────────────────────────────────────────────────── -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <div class="brand-logo">
        <div class="brand-icon">🏛️</div>
        <div>
          <div class="brand-name">Family Registry</div>
          <div class="brand-sub">District Management</div>
        </div>
      </div>
    </div>

    <nav class="sidebar-nav">
      <div class="nav-section">Main</div>
      <a class="nav-item" data-page="dashboard"><i class="fa fa-th-large"></i> Dashboard</a>
      <a class="nav-item" data-page="districts"><i class="fa fa-map-marker-alt"></i> Districts</a>
      <a class="nav-item" data-page="families"><i class="fa fa-home"></i> Families</a>
      <a class="nav-item" data-page="members"><i class="fa fa-users"></i> Members</a>
      <div class="nav-section">Reports</div>
      <a class="nav-item" data-page="reports"><i class="fa fa-chart-bar"></i> Reports</a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-card">
        <div class="user-avatar"><?= strtoupper(substr($user['full_name'] ?? $user['username'], 0, 1)) ?></div>
        <div class="user-info">
          <div class="name"><?= htmlspecialchars($user['full_name'] ?? $user['username']) ?></div>
          <div class="role"><?= htmlspecialchars($user['role'] ?? '') ?></div>
        </div>
        <a href="logout.php" class="btn-logout" title="Sign out"><i class="fa fa-sign-out-alt"></i></a>
      </div>
    </div>
  </aside>

  <!-- ── MAIN ────────────────────────────────────────────────────────── -->
  <main class="main">
    <header class="topbar">
      <button class="btn btn-outline btn-icon" id="sidebar-toggle" style="display:none"><i class="fa fa-bars"></i></button>
      <span class="topbar-title" id="topbar-title">Dashboard</span>
      <div style="flex:1"></div>
      <div class="topbar-search">
        <i class="fa fa-search"></i>
        <input type="text" id="global-search" placeholder="Quick search…">
      </div>
    </header>

    <div class="page-content">

      <!-- ══════════════════════════════════════════════════════════════ -->
      <!-- DASHBOARD                                                      -->
      <!-- ══════════════════════════════════════════════════════════════ -->
      <section id="page-dashboard" class="page-section">
        <div class="page-header">
          <div><h2>Dashboard</h2><p>Overview of district family registry</p></div>
          <button class="btn btn-outline" onclick="load_dashboard()"><i class="fa fa-sync-alt"></i> Refresh</button>
        </div>

        <div class="stats-grid" id="dash-stats">
          <?php foreach(['Districts','Families','Members','Active Families'] as $s): ?>
          <div class="stat-card"><div class="stat-icon blue"><i class="fa fa-spinner fa-spin"></i></div><div><div class="stat-value">—</div><div class="stat-label"><?= $s ?></div></div></div>
          <?php endforeach; ?>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:1.25rem">
          <div class="card">
            <div class="card-header"><span class="card-title">📍 Members by District</span></div>
            <div class="card-body" id="dash-by-district" style="min-height:200px"></div>
          </div>
          <div class="card">
            <div class="card-header"><span class="card-title">👥 Gender Breakdown</span></div>
            <div class="card-body" id="dash-gender" style="min-height:200px;display:flex;align-items:center;justify-content:center"></div>
          </div>
        </div>

        <div class="card">
          <div class="card-header"><span class="card-title">🏠 Recently Registered Families</span></div>
          <div class="table-wrap">
            <table id="dash-recent-table">
              <thead><tr><th>Family</th><th>Code</th><th>District</th><th>Status</th><th>Date</th></tr></thead>
              <tbody><tr class="loading-row"><td colspan="5">Loading…</td></tr></tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- ══════════════════════════════════════════════════════════════ -->
      <!-- DISTRICTS                                                      -->
      <!-- ══════════════════════════════════════════════════════════════ -->
      <section id="page-districts" class="page-section" style="display:none">
        <div class="page-header">
          <div><h2>Districts</h2><p>Manage all districts</p></div>
          <button class="btn btn-primary" onclick="openDistrictModal()"><i class="fa fa-plus"></i> Add District</button>
        </div>
        <div class="card">
          <div class="filter-bar">
            <input type="text" id="dist-search" placeholder="Search name, code…" oninput="load_districts()">
          </div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>#</th><th>Name</th><th>Code</th><th>Province</th><th>Families</th><th>Members</th><th>Actions</th></tr></thead>
              <tbody id="dist-tbody"><tr class="loading-row"><td colspan="7">Loading…</td></tr></tbody>
            </table>
          </div>
          <div class="pagination" id="dist-pag"></div>
        </div>
      </section>

      <!-- ══════════════════════════════════════════════════════════════ -->
      <!-- FAMILIES                                                       -->
      <!-- ══════════════════════════════════════════════════════════════ -->
      <section id="page-families" class="page-section" style="display:none">
        <div class="page-header">
          <div><h2>Families</h2><p>Manage registered families per district</p></div>
          <button class="btn btn-primary" onclick="openFamilyModal()"><i class="fa fa-plus"></i> Add Family</button>
        </div>
        <div class="card">
          <div class="filter-bar">
            <input type="text" id="fam-search" placeholder="Search family…" oninput="load_families()">
            <select id="fam-district" onchange="load_families()"><option value="">All Districts</option></select>
            <select id="fam-status" onchange="load_families()">
              <option value="">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>#</th><th>Family Name</th><th>Code</th><th>District</th><th>Phone</th><th>Members</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody id="fam-tbody"><tr class="loading-row"><td colspan="8">Loading…</td></tr></tbody>
            </table>
          </div>
          <div class="pagination" id="fam-pag"></div>
        </div>
      </section>

      <!-- ══════════════════════════════════════════════════════════════ -->
      <!-- MEMBERS                                                        -->
      <!-- ══════════════════════════════════════════════════════════════ -->
      <section id="page-members" class="page-section" style="display:none">
        <div class="page-header">
          <div><h2>Members</h2><p>Manage all family members</p></div>
          <button class="btn btn-primary" onclick="openMemberModal()"><i class="fa fa-plus"></i> Add Member</button>
        </div>
        <div class="card">
          <div class="filter-bar">
            <input type="text" id="mem-search" placeholder="Search name, ID card…" oninput="load_members()">
            <select id="mem-district" onchange="filterMembersByDistrict()"><option value="">All Districts</option></select>
            <select id="mem-family" onchange="load_members()"><option value="">All Families</option></select>
            <select id="mem-gender" onchange="load_members()">
              <option value="">All Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
            <select id="mem-status" onchange="load_members()">
              <option value="">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="deceased">Deceased</option>
              <option value="migrated">Migrated</option>
            </select>
          </div>
          <div class="table-wrap">
            <table>
              <thead><tr><th>#</th><th>Name</th><th>Gender</th><th>Age</th><th>Family</th><th>District</th><th>Relationship</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody id="mem-tbody"><tr class="loading-row"><td colspan="9">Loading…</td></tr></tbody>
            </table>
          </div>
          <div class="pagination" id="mem-pag"></div>
        </div>
      </section>

      <!-- ══════════════════════════════════════════════════════════════ -->
      <!-- REPORTS                                                        -->
      <!-- ══════════════════════════════════════════════════════════════ -->
      <section id="page-reports" class="page-section" style="display:none">
        <div class="page-header"><div><h2>Reports</h2><p>Summary statistics by district</p></div></div>
        <div id="reports-content"><div class="empty-state"><div class="icon">📊</div><p>Loading report…</p></div></div>
      </section>

    </div><!-- /page-content -->
  </main>
</div><!-- /app-wrap -->

<!-- ════════════════════ MODALS ════════════════════════════════════════════ -->

<!-- District Modal -->
<div class="modal-overlay" id="modal-district">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title" id="dist-modal-title">Add District</span>
      <button class="modal-close">&times;</button>
    </div>
    <div class="modal-body">
      <form id="form-district">
        <input type="hidden" name="id" id="dist-id">
        <div class="form-row col-2">
          <div class="form-group"><label>District Name *</label><input type="text" name="name" placeholder="e.g. Chamkar Mon" required></div>
          <div class="form-group"><label>Code *</label><input type="text" name="code" placeholder="e.g. CMK" required></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Province / City</label><input type="text" name="province" placeholder="e.g. Phnom Penh"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Description</label><textarea name="description" placeholder="Optional notes…"></textarea></div>
        </div>
        <div class="form-actions">
          <button type="button" class="btn btn-outline modal-close">Cancel</button>
          <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save District</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Family Modal -->
<div class="modal-overlay" id="modal-family">
  <div class="modal" style="max-width:720px">
    <div class="modal-header">
      <span class="modal-title" id="fam-modal-title">Add Family</span>
      <button class="modal-close">&times;</button>
    </div>
    <div class="modal-body">
      <form id="form-family">
        <input type="hidden" name="id" id="fam-id">
        <div class="form-row col-2">
          <div class="form-group"><label>Family Name *</label><input type="text" name="family_name" required></div>
          <div class="form-group"><label>Family Code</label><input type="text" name="family_code" placeholder="Auto-generated if blank"></div>
        </div>
        <div class="form-row col-2">
          <div class="form-group">
            <label>District *</label>
            <select name="district_id" id="fam-modal-district" required><option value="">Select District</option></select>
          </div>
          <div class="form-group"><label>Phone</label><input type="text" name="phone"></div>
        </div>
        <div class="form-row col-2">
          <div class="form-group"><label>Email</label><input type="email" name="email"></div>
          <div class="form-group"><label>Registration Date</label><input type="date" name="registration_date"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Address</label><textarea name="address" style="min-height:70px"></textarea></div>
        </div>
        <div class="form-row col-2">
          <div class="form-group">
            <label>Status</label>
            <select name="status"><option value="active">Active</option><option value="inactive">Inactive</option></select>
          </div>
          <div class="form-group"><label>Notes</label><input type="text" name="notes"></div>
        </div>
        <div class="form-actions">
          <button type="button" class="btn btn-outline modal-close">Cancel</button>
          <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save Family</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Member Modal -->
<div class="modal-overlay" id="modal-member">
  <div class="modal" style="max-width:760px">
    <div class="modal-header">
      <span class="modal-title" id="mem-modal-title">Add Member</span>
      <button class="modal-close">&times;</button>
    </div>
    <div class="modal-body">
      <form id="form-member">
        <input type="hidden" name="id" id="mem-id">
        <div class="form-row col-2">
          <div class="form-group"><label>First Name *</label><input type="text" name="first_name" required></div>
          <div class="form-group"><label>Last Name *</label><input type="text" name="last_name" required></div>
        </div>
        <div class="form-row col-3">
          <div class="form-group">
            <label>Gender</label>
            <select name="gender"><option value="male">Male</option><option value="female">Female</option><option value="other">Other</option></select>
          </div>
          <div class="form-group"><label>Date of Birth</label><input type="date" name="date_of_birth"></div>
          <div class="form-group"><label>ID Card / Passport</label><input type="text" name="id_card"></div>
        </div>
        <div class="form-row col-2">
          <div class="form-group">
            <label>Family *</label>
            <select name="family_id" id="mem-modal-family" required><option value="">Select Family</option></select>
          </div>
          <div class="form-group">
            <label>Relationship</label>
            <select name="relationship">
              <option value="head">Head of Family</option>
              <option value="spouse">Spouse</option>
              <option value="child">Child</option>
              <option value="parent">Parent</option>
              <option value="sibling">Sibling</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>
        <div class="form-row col-2">
          <div class="form-group"><label>Phone</label><input type="text" name="phone"></div>
          <div class="form-group"><label>Email</label><input type="email" name="email"></div>
        </div>
        <div class="form-row col-2">
          <div class="form-group"><label>Occupation</label><input type="text" name="occupation"></div>
          <div class="form-group"><label>Education</label><input type="text" name="education"></div>
        </div>
        <div class="form-row col-2">
          <div class="form-group">
            <label>Status</label>
            <select name="status">
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="deceased">Deceased</option>
              <option value="migrated">Migrated</option>
            </select>
          </div>
          <div class="form-group"><label>Notes</label><input type="text" name="notes"></div>
        </div>
        <div class="form-actions">
          <button type="button" class="btn btn-outline modal-close">Cancel</button>
          <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save Member</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Family Detail Modal -->
<div class="modal-overlay" id="modal-family-detail">
  <div class="modal" style="max-width:800px">
    <div class="modal-header">
      <span class="modal-title" id="fd-title">Family Details</span>
      <button class="modal-close">&times;</button>
    </div>
    <div class="modal-body" id="fd-body">Loading…</div>
  </div>
</div>

<!-- ════════════════════ SCRIPTS ═══════════════════════════════════════════ -->
<script src="js/app.js"></script>
<script>
/* ── PAGE TITLES ─────────────────────────────────────────────────────────── */
const PAGE_TITLES = { dashboard:'Dashboard', districts:'Districts', families:'Families', members:'Members', reports:'Reports' };
document.querySelectorAll('.nav-item[data-page]').forEach(n => {
  const orig = n.addEventListener;
  n.addEventListener('click', () => { document.getElementById('topbar-title').textContent = PAGE_TITLES[n.dataset.page] || ''; }, true);
});

/* ═══════════════════════════════════════════════════════════════════════════
   DASHBOARD
═══════════════════════════════════════════════════════════════════════════ */
let dashLoaded = false;
async function load_dashboard() {
  const r = await ajax('ajax/dashboard.php?action=stats', {}, 'GET');
  if (!r.success) return;
  const d = r.data;

  // Stats
  const icons  = ['fa-map-marker-alt blue','fa-home green','fa-users amber','fa-check-circle purple'];
  const labels = ['Districts','Families','Members','Active Families'];
  const vals   = [d.stats.districts, d.stats.families, d.stats.members, d.stats.active_families];
  document.getElementById('dash-stats').innerHTML = vals.map((v,i) => `
    <div class="stat-card">
      <div class="stat-icon ${icons[i].split(' ')[1]}"><i class="fa ${icons[i].split(' ')[0]}"></i></div>
      <div><div class="stat-value">${v}</div><div class="stat-label">${labels[i]}</div></div>
    </div>`).join('');

  // By district
  const maxCount = Math.max(...d.by_district.map(x => +x.count), 1);
  document.getElementById('dash-by-district').innerHTML = d.by_district.map(x => `
    <div style="margin-bottom:.75rem">
      <div style="display:flex;justify-content:space-between;font-size:.85rem;margin-bottom:.25rem">
        <span>${x.name}</span><strong>${x.count}</strong>
      </div>
      <div style="background:#f1f5f9;border-radius:99px;height:8px;overflow:hidden">
        <div style="width:${(x.count/maxCount*100).toFixed(1)}%;height:100%;background:var(--primary);border-radius:99px;transition:.6s"></div>
      </div>
    </div>`).join('') || '<div class="empty-state"><p>No data</p></div>';

  // Gender
  const gColors = { male:'#3b82f6', female:'#ec4899', other:'#8b5cf6' };
  const totalG  = d.gender.reduce((s,x) => s + +x.count, 0) || 1;
  document.getElementById('dash-gender').innerHTML = `
    <div style="text-align:center;width:100%">
      <div style="display:flex;justify-content:center;gap:1rem;flex-wrap:wrap">
        ${d.gender.map(g => `
          <div style="text-align:center">
            <div style="width:64px;height:64px;border-radius:50%;background:${gColors[g.gender]||'#64748b'};display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.5rem;margin:0 auto .5rem">${g.gender==='male'?'♂':'♀'}</div>
            <div style="font-weight:700">${g.count}</div>
            <div style="font-size:.8rem;color:var(--muted);text-transform:capitalize">${g.gender}</div>
            <div style="font-size:.78rem;color:var(--muted)">${(g.count/totalG*100).toFixed(1)}%</div>
          </div>`).join('')}
      </div>
    </div>`;

  // Recent families
  const tbody = document.querySelector('#dash-recent-table tbody');
  tbody.innerHTML = d.recent_families.length
    ? d.recent_families.map(f => `
        <tr>
          <td><strong>${f.family_name}</strong></td>
          <td><code style="font-size:.82rem;background:#f1f5f9;padding:.15rem .4rem;border-radius:4px">${f.family_code}</code></td>
          <td>${f.district_name}</td>
          <td>${badgeFamilyStatus(f.status)}</td>
          <td>${f.created_at?.slice(0,10) || '—'}</td>
        </tr>`).join('')
    : '<tr class="loading-row"><td colspan="5">No families yet</td></tr>';
}

/* ═══════════════════════════════════════════════════════════════════════════
   DISTRICTS
═══════════════════════════════════════════════════════════════════════════ */
let distPage = 1;
async function load_districts() {
  const search = document.getElementById('dist-search').value;
  const r = await ajax(`ajax/districts.php?action=list&page=${distPage}&search=${encodeURIComponent(search)}`, {}, 'GET');
  if (!r.success) { Toast.error(r.message); return; }
  const { rows, pagination } = r.data;

  const tbody = document.getElementById('dist-tbody');
  if (!rows.length) { tbody.innerHTML = '<tr class="loading-row"><td colspan="7"><div class="empty-state"><div class="icon">🗺️</div><p>No districts found</p></div></td></tr>'; }
  else tbody.innerHTML = rows.map((d, i) => `
    <tr>
      <td>${(pagination.current-1)*pagination.per_page+i+1}</td>
      <td><strong>${d.name}</strong></td>
      <td><code style="background:#f1f5f9;padding:.15rem .45rem;border-radius:4px;font-size:.82rem">${d.code}</code></td>
      <td>${d.province || '—'}</td>
      <td><span class="badge badge-info">${d.family_count}</span></td>
      <td><span class="badge badge-success">${d.member_count}</span></td>
      <td>
        <div style="display:flex;gap:.35rem">
          <button class="btn btn-outline btn-sm btn-icon" onclick="editDistrict(${d.id})" title="Edit"><i class="fa fa-edit"></i></button>
          <button class="btn btn-danger btn-sm btn-icon" onclick="deleteDistrict(${d.id},'${d.name}')" title="Delete"><i class="fa fa-trash"></i></button>
        </div>
      </td>
    </tr>`).join('');

  renderPagination(document.getElementById('dist-pag'), pagination.current, pagination.total_pages, p => { distPage = p; load_districts(); });
  const pi = document.createElement('span'); pi.className='page-info'; pi.textContent=`${pagination.total} total`;
  document.getElementById('dist-pag').appendChild(pi);
}

function openDistrictModal(id = 0) {
  resetForm('form-district');
  document.getElementById('dist-modal-title').textContent = id ? 'Edit District' : 'Add District';
  document.getElementById('dist-id').value = id;
  Modal.open('modal-district');
}

async function editDistrict(id) {
  openDistrictModal(id);
  const r = await ajax(`ajax/districts.php?action=get&id=${id}`, {}, 'GET');
  if (r.success) populateForm('form-district', r.data);
}

// async function deleteDistrict(id, name) {
//   if (!await confirmDelete(`Delete district "${name}"? This cannot be undone.`)) return;
//   const r = await ajax('ajax/districts.php', { action:'delete', id });
//   if (r.success) { Toast.success(r.message); load_districts(); }
//   else Toast.error(r.message);
// }


async function deleteDistrict(id, name) {
  if (!await confirmDelete(`Delete  disstrict "${name}"?`)) return;

  const fd = new FormData();
  fd.append('action', 'delete');
  fd.append('id', id);

  const r = await ajax('ajax/districts.php', fd);

  if (r.success) {
    Toast.success(r.message);
    load_districts();
  } else {
    Toast.error(r.message);
  }
}






document.getElementById('form-district').addEventListener('submit', async e => {
  e.preventDefault();
  const fd = new FormData(e.target); fd.append('action','save');
  const r  = await ajax('ajax/districts.php', fd);
  if (r.success) { Toast.success(r.message); Modal.close('modal-district'); load_districts(); }
  else Toast.error(r.message);
});

/* ═══════════════════════════════════════════════════════════════════════════
   FAMILIES
═══════════════════════════════════════════════════════════════════════════ */
let famPage = 1;
async function load_families() {
  const search = document.getElementById('fam-search').value;
  const dist   = document.getElementById('fam-district').value;
  const status = document.getElementById('fam-status').value;
  const r = await ajax(`ajax/families.php?action=list&page=${famPage}&search=${encodeURIComponent(search)}&district_id=${dist}&status=${status}`, {}, 'GET');
  if (!r.success) { Toast.error(r.message); return; }
  const { rows, pagination } = r.data;

  const tbody = document.getElementById('fam-tbody');
  if (!rows.length) { tbody.innerHTML = '<tr class="loading-row"><td colspan="8"><div class="empty-state"><div class="icon">🏠</div><p>No families found</p></div></td></tr>'; }
  else tbody.innerHTML = rows.map((f, i) => `
    <tr>
      <td>${(pagination.current-1)*pagination.per_page+i+1}</td>
      <td><a href="#" onclick="viewFamilyDetail(${f.id})" style="color:var(--primary);font-weight:600;text-decoration:none">${f.family_name}</a></td>
      <td><code style="background:#f1f5f9;padding:.15rem .45rem;border-radius:4px;font-size:.8rem">${f.family_code}</code></td>
      <td>${f.district_name}</td>
      <td>${f.phone || '—'}</td>
      <td><span class="badge badge-info">${f.member_count} members</span></td>
      <td>${badgeFamilyStatus(f.status)}</td>
      <td>
        <div style="display:flex;gap:.35rem">
          <button class="btn btn-outline btn-sm btn-icon" onclick="viewFamilyDetail(${f.id})" title="View Members"><i class="fa fa-eye"></i></button>
          <button class="btn btn-outline btn-sm btn-icon" onclick="editFamily(${f.id})" title="Edit"><i class="fa fa-edit"></i></button>
          <button class="btn btn-danger btn-sm btn-icon" onclick="deleteFamily(${f.id},'${f.family_name}')" title="Delete"><i class="fa fa-trash"></i></button>
        </div>
      </td>
    </tr>`).join('');

  renderPagination(document.getElementById('fam-pag'), pagination.current, pagination.total_pages, p => { famPage = p; load_families(); });
  const pi = document.createElement('span'); pi.className='page-info'; pi.textContent=`${pagination.total} total`;
  document.getElementById('fam-pag').appendChild(pi);
}

async function openFamilyModal(id = 0) {
  resetForm('form-family');
  document.getElementById('fam-modal-title').textContent = id ? 'Edit Family' : 'Add Family';
  document.getElementById('fam-id').value = id;
  await loadDistrictDropdown('fam-modal-district');
  Modal.open('modal-family');
}

async function editFamily(id) {
  await openFamilyModal(id);
  const r = await ajax(`ajax/families.php?action=get&id=${id}`, {}, 'GET');
  if (r.success) populateForm('form-family', r.data);
}

async function deleteFamily(id, name) {
  if (!await confirmDelete(`Delete family "${name}"?`)) return;

  const fd = new FormData();
  fd.append('action', 'delete');
  fd.append('id', id);

  const r = await ajax('ajax/families.php', fd);

  if (r.success) {
    Toast.success(r.message);
    load_families();
  } else {
    Toast.error(r.message);
  }
}

async function viewFamilyDetail(fid) {
  document.getElementById('fd-title').textContent = 'Family Members';
  document.getElementById('fd-body').innerHTML = '<div style="text-align:center;padding:2rem;color:var(--muted)"><i class="fa fa-spinner fa-spin fa-2x"></i></div>';
  Modal.open('modal-family-detail');
  const r = await ajax(`ajax/members.php?action=by_family&family_id=${fid}`, {}, 'GET');
  if (!r.success) { document.getElementById('fd-body').innerHTML = '<p>Error loading members.</p>'; return; }

  const fr = await ajax(`ajax/families.php?action=get&id=${fid}`, {}, 'GET');
  const fam = fr.data;
  const rows = r.data;
  document.getElementById('fd-title').textContent = `${fam.family_name} — Members`;
  document.getElementById('fd-body').innerHTML = `
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:.75rem;margin-bottom:1.25rem;padding-bottom:1.25rem;border-bottom:1px solid var(--border)">
      <div><div style="font-size:.75rem;color:var(--muted);font-weight:600;text-transform:uppercase">District</div><div>${fam.district_name||'—'}</div></div>
      <div><div style="font-size:.75rem;color:var(--muted);font-weight:600;text-transform:uppercase">Code</div><div><code>${fam.family_code}</code></div></div>
      <div><div style="font-size:.75rem;color:var(--muted);font-weight:600;text-transform:uppercase">Phone</div><div>${fam.phone||'—'}</div></div>
    </div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem">
      <strong>${rows.length} Member${rows.length!==1?'s':''}</strong>
      <button class="btn btn-primary btn-sm" onclick="Modal.close('modal-family-detail');addMemberToFamily(${fid})"><i class="fa fa-plus"></i> Add Member</button>
    </div>
    ${rows.length ? `<div class="table-wrap"><table>
      <thead><tr><th>Name</th><th>Relation</th><th>Gender</th><th>Age</th><th>Occupation</th><th>Status</th><th></th></tr></thead>
      <tbody>${rows.map(m => `
        <tr>
          <td><strong>${m.first_name} ${m.last_name}</strong></td>
          <td><span class="badge badge-info" style="text-transform:capitalize">${m.relationship}</span></td>
          <td style="text-transform:capitalize">${m.gender}</td>
          <td>${m.age ?? '—'}</td>
          <td>${m.occupation||'—'}</td>
          <td>${badgeMemberStatus(m.status)}</td>
          <td>
            <div style="display:flex;gap:.35rem">
              <button class="btn btn-outline btn-sm btn-icon" onclick="Modal.close('modal-family-detail');editMember(${m.id})"><i class="fa fa-edit"></i></button>
              <button class="btn btn-danger btn-sm btn-icon" onclick="deleteMemberFromDetail(${m.id},${fid})"><i class="fa fa-trash"></i></button>
            </div>
          </td>
        </tr>`).join('')}</tbody>
    </table></div>` : '<div class="empty-state"><div class="icon">👥</div><p>No members yet</p></div>'}`;
}

async function deleteMemberFromDetail(mid, fid) {
  if (!await confirmDelete('Delete this member?')) return;
  const r = await ajax('ajax/members.php', { action:'delete', id:mid });
  if (r.success) { Toast.success(r.message); viewFamilyDetail(fid); }
  else Toast.error(r.message);
}

document.getElementById('form-family').addEventListener('submit', async e => {
  e.preventDefault();
  const fd = new FormData(e.target); fd.append('action','save');
  const r  = await ajax('ajax/families.php', fd);
  if (r.success) { Toast.success(r.message); Modal.close('modal-family'); load_families(); }
  else Toast.error(r.message);
});

/* ═══════════════════════════════════════════════════════════════════════════
   MEMBERS
═══════════════════════════════════════════════════════════════════════════ */
let memPage = 1;
async function load_members() {
  const search = document.getElementById('mem-search').value;
  const family = document.getElementById('mem-family').value;
  const gender = document.getElementById('mem-gender').value;
  const status = document.getElementById('mem-status').value;
  const dist   = document.getElementById('mem-district').value;
  const r = await ajax(`ajax/members.php?action=list&page=${memPage}&search=${encodeURIComponent(search)}&family_id=${family}&gender=${gender}&status=${status}&district_id=${dist}`, {}, 'GET');
  if (!r.success) { Toast.error(r.message); return; }
  const { rows, pagination } = r.data;

  const tbody = document.getElementById('mem-tbody');
  if (!rows.length) { tbody.innerHTML = '<tr class="loading-row"><td colspan="9"><div class="empty-state"><div class="icon">👤</div><p>No members found</p></div></td></tr>'; }
  else tbody.innerHTML = rows.map((m,i) => `
    <tr>
      <td>${(pagination.current-1)*pagination.per_page+i+1}</td>
      <td><strong>${m.first_name} ${m.last_name}</strong><br><small style="color:var(--muted)">${m.id_card||''}</small></td>
      <td style="text-transform:capitalize">${m.gender}</td>
      <td>${m.age ?? '—'}</td>
      <td>${m.family_name}</td>
      <td>${m.district_name}</td>
      <td><span class="badge badge-info" style="text-transform:capitalize">${m.relationship}</span></td>
      <td>${badgeMemberStatus(m.status)}</td>
      <td>
        <div style="display:flex;gap:.35rem">
          <button class="btn btn-outline btn-sm btn-icon" onclick="editMember(${m.id})" title="Edit"><i class="fa fa-edit"></i></button>
          <button class="btn btn-danger btn-sm btn-icon" onclick="deleteMember(${m.id},'${m.first_name} ${m.last_name}')" title="Delete"><i class="fa fa-trash"></i></button>
        </div>
      </td>
    </tr>`).join('');

  renderPagination(document.getElementById('mem-pag'), pagination.current, pagination.total_pages, p => { memPage = p; load_members(); });
  const pi = document.createElement('span'); pi.className='page-info'; pi.textContent=`${pagination.total} total`;
  document.getElementById('mem-pag').appendChild(pi);
}

async function openMemberModal(id = 0) {
  resetForm('form-member');
  document.getElementById('mem-modal-title').textContent = id ? 'Edit Member' : 'Add Member';
  document.getElementById('mem-id').value = id;
  await loadFamilyDropdown('mem-modal-family');
  Modal.open('modal-member');
}

async function addMemberToFamily(familyId) {
  await openMemberModal();
  document.getElementById('mem-modal-family').value = familyId;
}

async function editMember(id) {
  await openMemberModal(id);
  const r = await ajax(`ajax/members.php?action=get&id=${id}`, {}, 'GET');
  if (r.success) populateForm('form-member', r.data);
}

// async function deleteMember(id, name) {
//   if (!await confirmDelete(`Delete member "${name}"?`)) return;
//   const r = await ajax('ajax/members.php', { action:'delete', id });
//   if (r.success) { Toast.success(r.message); load_members(); }
//   else Toast.error(r.message);
// }



async function deleteMember(id, name) {
  if (!await confirmDelete(`Delete  member "${name}"?`)) return;

  const fd = new FormData();
  fd.append('action', 'delete');
  fd.append('id', id);

  const r = await ajax('ajax/members.php', fd);

  if (r.success) {
    Toast.success(r.message);
    load_members();
  } else {
    Toast.error(r.message);
  }
}


document.getElementById('form-member').addEventListener('submit', async e => {
  e.preventDefault();
  const fd = new FormData(e.target); fd.append('action','save');
  const r  = await ajax('ajax/members.php', fd);
  if (r.success) { Toast.success(r.message); Modal.close('modal-member'); load_members(); }
  else Toast.error(r.message);
});

/* ═══════════════════════════════════════════════════════════════════════════
   REPORTS
═══════════════════════════════════════════════════════════════════════════ */
async function load_reports() {
  const r = await ajax('ajax/dashboard.php?action=stats', {}, 'GET');
  if (!r.success) return;
  const d = r.data;
  document.getElementById('reports-content').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem">
      <div class="card">
        <div class="card-header"><span class="card-title">📍 District Summary</span></div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>District</th><th>Members</th><th>Bar</th></tr></thead>
            <tbody>${(() => {
              const max = Math.max(...d.by_district.map(x => +x.count), 1);
              return d.by_district.map(x => `
                <tr>
                  <td><strong>${x.name}</strong></td>
                  <td>${x.count}</td>
                  <td style="width:200px">
                    <div style="background:#f1f5f9;border-radius:99px;height:8px">
                      <div style="width:${(x.count/max*100).toFixed(1)}%;height:100%;background:var(--primary);border-radius:99px"></div>
                    </div>
                  </td>
                </tr>`).join('');
            })()}</tbody>
          </table>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title">👥 Member Statistics</span></div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1rem">
            <div style="text-align:center;padding:1rem;background:var(--bg);border-radius:10px">
              <div style="font-size:2rem;font-weight:700;color:var(--primary)">${d.stats.members}</div>
              <div style="color:var(--muted);font-size:.85rem">Total Members</div>
            </div>
            <div style="text-align:center;padding:1rem;background:var(--bg);border-radius:10px">
              <div style="font-size:2rem;font-weight:700;color:var(--success)">${d.stats.families}</div>
              <div style="color:var(--muted);font-size:.85rem">Total Families</div>
            </div>
          </div>
          <div><strong style="font-size:.82rem;color:var(--muted);text-transform:uppercase;letter-spacing:.05em">Gender Distribution</strong></div>
          <div style="margin-top:.75rem">
            ${d.gender.map(g => `
              <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:.5rem">
                <div style="width:80px;font-size:.88rem;text-transform:capitalize">${g.gender}</div>
                <div style="flex:1;background:#f1f5f9;border-radius:99px;height:12px">
                  <div style="width:${(g.count/d.stats.members*100).toFixed(1)}%;height:100%;background:${g.gender==='male'?'#3b82f6':g.gender==='female'?'#ec4899':'#8b5cf6'};border-radius:99px"></div>
                </div>
                <div style="width:50px;text-align:right;font-weight:600">${g.count}</div>
              </div>`).join('')}
          </div>
        </div>
      </div>
    </div>`;
}

/* ═══════════════════════════════════════════════════════════════════════════
   HELPERS & DROPDOWNS
═══════════════════════════════════════════════════════════════════════════ */
async function loadDistrictDropdown(selectId, includeAll = false) {
  const r = await ajax('ajax/districts.php?action=dropdown', {}, 'GET');
  if (!r.success) return;
  const el = document.getElementById(selectId);
  el.innerHTML = (includeAll ? '<option value="">All Districts</option>' : '<option value="">Select District</option>') +
    r.data.map(d => `<option value="${d.id}">${d.name}</option>`).join('');
}

async function loadFamilyDropdown(selectId, districtId = 0) {
  const r = await ajax(`ajax/families.php?action=dropdown&district_id=${districtId}`, {}, 'GET');
  if (!r.success) return;
  const el = document.getElementById(selectId);
  el.innerHTML = '<option value="">Select Family</option>' + r.data.map(f => `<option value="${f.id}">${f.family_name}</option>`).join('');
}

async function filterMembersByDistrict() {
  const dist = document.getElementById('mem-district').value;
  await loadFamilyDropdown('mem-family', dist);
  load_members();
}

function badgeFamilyStatus(s) {
  const cls = { active:'badge-success', inactive:'badge-danger' };
  return `<span class="badge ${cls[s]||'badge-muted'}" style="text-transform:capitalize">${s}</span>`;
}
function badgeMemberStatus(s) {
  const cls = { active:'badge-success', inactive:'badge-muted', deceased:'badge-danger', migrated:'badge-warning' };
  return `<span class="badge ${cls[s]||'badge-muted'}" style="text-transform:capitalize">${s}</span>`;
}

/* ═══════════════════════════════════════════════════════════════════════════
   INIT FILTERS ON FAMILIES/MEMBERS PAGES
═══════════════════════════════════════════════════════════════════════════ */
const origNav = navigateTo;
window.navigateTo = async function(page) {
  origNav(page);
  if (page === 'families') { await loadDistrictDropdown('fam-district', true); }
  if (page === 'members')  { await loadDistrictDropdown('mem-district', true); await loadFamilyDropdown('mem-family'); }
};
</script>
</body>
</html>
