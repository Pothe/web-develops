<?php
require_once '../includes/functions.php';
requireLogin();
header('Content-Type: application/json');

$conn   = getConnection();
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

  case 'list':
    $page        = max(1, (int)($_GET['page'] ?? 1));
    $perPage     = 10;
    $search      = escape($conn, sanitize($_GET['search'] ?? ''));
    $district_id = (int)($_GET['district_id'] ?? 0);
    $status      = escape($conn, sanitize($_GET['status'] ?? ''));

    $where = ['1=1'];
    if ($search) $where[] = "(f.family_name LIKE '%$search%' OR f.family_code LIKE '%$search%' OR f.phone LIKE '%$search%')";
    if ($district_id) $where[] = "f.district_id=$district_id";
    if ($status) $where[] = "f.status='$status'";
    $where = 'WHERE ' . implode(' AND ', $where);

    $total  = $conn->query("SELECT COUNT(*) as c FROM families f $where")->fetch_assoc()['c'];
    $pag    = paginate($total, $perPage, $page);

    $sql = "SELECT f.*, d.name AS district_name,
              (SELECT COUNT(*) FROM members m WHERE m.family_id=f.id) AS member_count
            FROM families f
            JOIN districts d ON f.district_id=d.id
            $where
            ORDER BY f.family_name ASC
            LIMIT {$pag['per_page']} OFFSET {$pag['offset']}";
    $res  = $conn->query($sql);
    $rows = [];
    while ($row = $res->fetch_assoc()) $rows[] = $row;
    jsonSuccess(['rows' => $rows, 'pagination' => $pag]);
    break;

  case 'get':
    $id  = (int)($_GET['id'] ?? 0);
    $sql = "SELECT f.*, d.name AS district_name FROM families f JOIN districts d ON f.district_id=d.id WHERE f.id=$id";
    $res = $conn->query($sql);
    if ($row = $res->fetch_assoc()) jsonSuccess($row);
    jsonError('Family not found', 404);
    break;

  case 'save':
    $id          = (int)($_POST['id'] ?? 0);
    $district_id = (int)($_POST['district_id'] ?? 0);
    $family_name = escape($conn, sanitize($_POST['family_name'] ?? ''));
    $family_code = escape($conn, sanitize($_POST['family_code'] ?? ''));
    $address     = escape($conn, sanitize($_POST['address'] ?? ''));
    $phone       = escape($conn, sanitize($_POST['phone'] ?? ''));
    $email       = escape($conn, sanitize($_POST['email'] ?? ''));
    $reg_date    = escape($conn, sanitize($_POST['registration_date'] ?? ''));
    $status      = escape($conn, sanitize($_POST['status'] ?? 'active'));
    $notes       = escape($conn, sanitize($_POST['notes'] ?? ''));

    if (!$family_name || !$district_id) jsonError('Family name and district are required.');
    if (!$family_code) $family_code = 'FAM-' . strtoupper(substr(md5(time()), 0, 8));
    $reg_date_val = $reg_date ? "'$reg_date'" : 'CURDATE()';

    if ($id) {
      $ok = $conn->query("UPDATE families SET district_id=$district_id,family_name='$family_name',family_code='$family_code',address='$address',phone='$phone',email='$email',registration_date=$reg_date_val,status='$status',notes='$notes' WHERE id=$id");
      if ($ok) jsonSuccess(['id' => $id], 'Family updated.');
      jsonError($conn->error);
    } else {
      $ok = $conn->query("INSERT INTO families(district_id,family_name,family_code,address,phone,email,registration_date,status,notes) VALUES($district_id,'$family_name','$family_code','$address','$phone','$email',$reg_date_val,'$status','$notes')");
      if ($ok) jsonSuccess(['id' => $conn->insert_id], 'Family created.');
      jsonError($conn->error);
    }
    break;

  case 'delete':
    $id = (int)($_POST['id'] ?? 0);
    $mc = $conn->query("SELECT COUNT(*) as c FROM members WHERE family_id=$id")->fetch_assoc()['c'];
    if ($mc > 0) jsonError("Cannot delete family with $mc members. Remove members first.");
    $ok = $conn->query("DELETE FROM families WHERE id = $id");
    if ($ok) jsonSuccess([], 'Family deleted.');
    jsonError($conn->error);
    break;

  case 'dropdown':
    $did = (int)($_GET['district_id'] ?? 0);
    $where = $did ? "WHERE district_id=$did" : '';
    $res  = $conn->query("SELECT id, family_name FROM families $where ORDER BY family_name ASC");
    $rows = [];
    while ($row = $res->fetch_assoc()) $rows[] = $row;
    jsonSuccess($rows);
    break;

  default:
    jsonError('Unknown action.', 400);
}
$conn->close();
?>
