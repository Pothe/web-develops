/* =============================================
   District Family Registry – Main JS / AJAX
   ============================================= */

// ─── Toast Notifications ─────────────────────────────────────────────────────
const Toast = {
  container: null,
  init() {
    this.container = document.createElement('div');
    this.container.className = 'toast-container';
    document.body.appendChild(this.container);
  },
  show(message, type = 'info', duration = 3500) {
    const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.innerHTML = `<span>${icons[type] || ''}</span><span>${message}</span>`;
    this.container.appendChild(el);
    setTimeout(() => {
      el.style.animation = 'slideIn .3s ease reverse';
      el.addEventListener('animationend', () => el.remove());
    }, duration);
  },
  success(m) { this.show(m, 'success'); },
  error(m)   { this.show(m, 'error'); },
  info(m)    { this.show(m, 'info'); },
};

// ─── AJAX Helper ─────────────────────────────────────────────────────────────
async function ajax(url, data = {}, method = 'POST') {
  try {
    const opts = { method, headers: {} };
    if (method === 'POST') {
      if (data instanceof FormData) {
        opts.body = data;
      } else {
        opts.headers['Content-Type'] = 'application/json';
        opts.body = JSON.stringify(data);
      }
    } else if (method === 'GET' && Object.keys(data).length) {
      url += '?' + new URLSearchParams(data);
    }
    const res  = await fetch(url, opts);
    const json = await res.json();
    return json;
  } catch (err) {
    console.error('AJAX error:', err);
    return { success: false, message: 'Network error. Please try again.' };
  }
}

// ─── Modal Management ────────────────────────────────────────────────────────
const Modal = {
  open(id)  { document.getElementById(id)?.classList.add('open'); },
  close(id) { document.getElementById(id)?.classList.remove('open'); },
  closeAll() { document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open')); },
};

document.addEventListener('keydown', e => { if (e.key === 'Escape') Modal.closeAll(); });
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) Modal.closeAll();
  if (e.target.classList.contains('modal-close'))   Modal.closeAll();
});

// ─── Confirm Dialog ──────────────────────────────────────────────────────────
function confirmDelete(message = 'Are you sure you want to delete this record?') {
  return new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay open';
    overlay.innerHTML = `
      <div class="modal" style="max-width:400px">
        <div class="modal-header"><span class="modal-title">⚠️ Confirm Delete</span></div>
        <div class="modal-body">
          <p style="margin-bottom:1.5rem;color:#64748b">${message}</p>
          <div style="display:flex;gap:.75rem;justify-content:flex-end">
            <button class="btn btn-outline" id="cfm-no">Cancel</button>
            <button class="btn btn-danger" id="cfm-yes">Delete</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.querySelector('#cfm-yes').onclick = () => { overlay.remove(); resolve(true); };
    overlay.querySelector('#cfm-no').onclick  = () => { overlay.remove(); resolve(true); };

  });
}

// ─── Table Pagination ─────────────────────────────────────────────────────────
function renderPagination(container, current, total, callback) {
  container.innerHTML = '';
  const prev = document.createElement('button');
  prev.className = 'page-btn'; prev.textContent = '‹'; prev.disabled = current === 1;
  prev.onclick = () => callback(current - 1);
  container.appendChild(prev);
  for (let i = 1; i <= total; i++) {
    if (total > 7 && i > 2 && i < total - 1 && Math.abs(i - current) > 1) {
      if (i === 3 || i === total - 2) { const sp = document.createElement('span'); sp.textContent = '…'; sp.style.padding = '0 .35rem'; container.appendChild(sp); }
      continue;
    }
    const btn = document.createElement('button');
    btn.className = 'page-btn' + (i === current ? ' active' : '');
    btn.textContent = i;
    btn.onclick = () => callback(i);
    container.appendChild(btn);
  }
  const next = document.createElement('button');
  next.className = 'page-btn'; next.textContent = '›'; next.disabled = current === total;
  next.onclick = () => callback(current + 1);
  container.appendChild(next);
}

// ─── Form Reset & Population ─────────────────────────────────────────────────
function resetForm(formId) {
  const form = document.getElementById(formId);
  if (form) { form.reset(); form.querySelectorAll('[data-id]').forEach(el => el.removeAttribute('data-id')); }
}

function populateForm(formId, data) {
  const form = document.getElementById(formId);
  if (!form) return;
  Object.entries(data).forEach(([k, v]) => {
    const el = form.querySelector(`[name="${k}"]`);
    if (el) el.value = v ?? '';
  });
}

// ─── Page Router (SPA-like) ──────────────────────────────────────────────────
function navigateTo(page) {
  document.querySelectorAll('.page-section').forEach(s => s.style.display = 'none');
  const target = document.getElementById('page-' + page);
  if (target) target.style.display = 'block';

  document.querySelectorAll('.nav-item').forEach(n => {
    n.classList.toggle('active', n.dataset.page === page);
  });

  if (typeof window['load_' + page] === 'function') window['load_' + page]();
}

// ─── Init ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  Toast.init();
  document.querySelectorAll('.nav-item[data-page]').forEach(item => {
    item.addEventListener('click', () => navigateTo(item.dataset.page));
  });
  navigateTo('dashboard');
});
