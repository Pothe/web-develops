<?php
require_once 'includes/functions.php';
if (isLoggedIn()) { header('Location: index.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn     = getConnection();
    $username = escape($conn, sanitize($_POST['username'] ?? ''));
    $password = $_POST['password'] ?? '';
    $res      = $conn->query("SELECT * FROM users WHERE username='$username' AND is_active=1");
    if ($res && $row = $res->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user']    = $row;
            $conn->query("UPDATE users SET last_login=NOW() WHERE id={$row['id']}");
            header('Location: index.php'); exit;
        }
    }
    $error = 'Invalid username or password.';
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login – District Family Registry</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  :root{--primary:#1a56db;--primary-dark:#1245b0;--accent:#f59e0b;--bg:#0f172a;--card:#1e293b;--text:#f1f5f9;--muted:#94a3b8;--border:#334155;--success:#10b981;--danger:#ef4444;}
  *{margin:0;padding:0;box-sizing:border-box;}
  body{font-family:'Outfit',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;display:flex;align-items:center;justify-content:center;background-image:radial-gradient(ellipse at 20% 50%,rgba(26,86,219,.15) 0,transparent 60%),radial-gradient(ellipse at 80% 20%,rgba(245,158,11,.08) 0,transparent 50%);}
  .login-wrap{width:100%;max-width:420px;padding:2rem;}
  .logo{text-align:center;margin-bottom:2.5rem;}
  .logo-icon{width:64px;height:64px;background:linear-gradient(135deg,var(--primary),var(--accent));border-radius:16px;display:inline-flex;align-items:center;justify-content:center;font-size:1.8rem;margin-bottom:1rem;}
  .logo h1{font-size:1.5rem;font-weight:700;letter-spacing:-.5px;}
  .logo p{color:var(--muted);font-size:.9rem;margin-top:.25rem;}
  .card{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:2rem;}
  .form-group{margin-bottom:1.25rem;}
  label{display:block;font-size:.85rem;font-weight:600;color:var(--muted);margin-bottom:.5rem;text-transform:uppercase;letter-spacing:.05em;}
  .input-wrap{position:relative;}
  .input-wrap i{position:absolute;left:1rem;top:50%;transform:translateY(-50%);color:var(--muted);font-size:.9rem;}
  input[type=text],input[type=password]{width:100%;padding:.85rem 1rem .85rem 2.75rem;background:#0f172a;border:1px solid var(--border);border-radius:10px;color:var(--text);font-family:'Outfit',sans-serif;font-size:1rem;transition:.2s;}
  input:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(26,86,219,.2);}
  .btn-login{width:100%;padding:.95rem;background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;border:none;border-radius:10px;font-family:'Outfit',sans-serif;font-size:1rem;font-weight:600;cursor:pointer;transition:.2s;margin-top:.5rem;}
  .btn-login:hover{transform:translateY(-1px);box-shadow:0 8px 24px rgba(26,86,219,.4);}
  .alert-error{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#fca5a5;padding:.85rem 1rem;border-radius:10px;margin-bottom:1.25rem;font-size:.9rem;display:flex;align-items:center;gap:.5rem;}
  .hint{text-align:center;margin-top:1.25rem;font-size:.82rem;color:var(--muted);}
  .hint code{background:#0f172a;padding:.2rem .5rem;border-radius:6px;color:var(--accent);}
</style>
</head>
<body>
<div class="login-wrap">
  <div class="logo">
    <div class="logo-icon">🏛️</div>
    <h1>District Family Registry</h1>
    <p>Secure administration portal</p>
  </div>
  <div class="card">
    <?php if ($error): ?><div class="alert-error"><i class="fa fa-exclamation-circle"></i><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
      <div class="form-group">
        <label>Username</label>
        <div class="input-wrap"><i class="fa fa-user"></i><input type="text" name="username" placeholder="Enter username" required autocomplete="username"></div>
      </div>
      <div class="form-group">
        <label>Password</label>
        <div class="input-wrap"><i class="fa fa-lock"></i><input type="password" name="password" placeholder="Enter password" required autocomplete="current-password"></div>
      </div>
      <button type="submit" class="btn-login"><i class="fa fa-sign-in-alt"></i> &nbsp;Sign In</button>
    </form>
    <div class="hint">Default: <code>admin</code> / <code>password</code></div>
  </div>
</div>
</body>
</html>
