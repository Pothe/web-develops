<?php
require_once 'config.php';
session_start();

// ─── Authentication ───────────────────────────────────────────────────────────

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function getCurrentUser() {
    return $_SESSION['user'] ?? null;
}

function isAdmin() {
    return ($_SESSION['user']['role'] ?? '') === 'admin';
}

// ─── Sanitization ────────────────────────────────────────────────────────────

function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

function escape($conn, $val) {
    return $conn->real_escape_string($val);
}

// ─── Pagination ──────────────────────────────────────────────────────────────

function paginate($total, $perPage, $currentPage) {
    $totalPages = ceil($total / $perPage);
    $offset     = ($currentPage - 1) * $perPage;
    return ['total_pages' => $totalPages, 'offset' => $offset, 'current' => $currentPage, 'per_page' => $perPage, 'total' => $total];
}

// ─── Response helpers ────────────────────────────────────────────────────────

function jsonSuccess($data = [], $message = 'Success') {
    echo json_encode(['success' => true, 'message' => $message, 'data' => $data]);
    exit;
}

function jsonError($message = 'Error', $code = 400) {
    http_response_code($code);
    echo json_encode(['success' => false, 'message' => $message]);
    exit;
}

// ─── Stats helpers ───────────────────────────────────────────────────────────

function getDashboardStats($conn) {
    $stats = [];
    $stats['districts'] = $conn->query("SELECT COUNT(*) as c FROM districts")->fetch_assoc()['c'];
    $stats['families']  = $conn->query("SELECT COUNT(*) as c FROM families")->fetch_assoc()['c'];
    $stats['members']   = $conn->query("SELECT COUNT(*) as c FROM members")->fetch_assoc()['c'];
    $stats['active_families'] = $conn->query("SELECT COUNT(*) as c FROM families WHERE status='active'")->fetch_assoc()['c'];
    return $stats;
}
?>
