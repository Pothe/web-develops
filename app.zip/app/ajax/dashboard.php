<?php
require_once '../includes/functions.php';
requireLogin();
header('Content-Type: application/json');
$conn   = getConnection();
$action = $_GET['action'] ?? '';

switch ($action) {
  case 'stats':
    $stats = getDashboardStats($conn);

    // Recent families
    $res = $conn->query("SELECT f.family_name, f.family_code, f.status, d.name AS district_name, f.created_at FROM families f JOIN districts d ON f.district_id=d.id ORDER BY f.created_at DESC LIMIT 5");
    $recent_families = [];
    while ($r = $res->fetch_assoc()) $recent_families[] = $r;

    // Members by district
    $res2 = $conn->query("SELECT d.name, COUNT(m.id) AS count FROM districts d LEFT JOIN families f ON f.district_id=d.id LEFT JOIN members m ON m.family_id=f.id GROUP BY d.id ORDER BY count DESC");
    $by_district = [];
    while ($r = $res2->fetch_assoc()) $by_district[] = $r;

    // Gender breakdown
    $res3 = $conn->query("SELECT gender, COUNT(*) as count FROM members GROUP BY gender");
    $gender = [];
    while ($r = $res3->fetch_assoc()) $gender[] = $r;

    // Status breakdown
    $res4 = $conn->query("SELECT status, COUNT(*) as count FROM families GROUP BY status");
    $fam_status = [];
    while ($r = $res4->fetch_assoc()) $fam_status[] = $r;

    jsonSuccess(compact('stats','recent_families','by_district','gender','fam_status'));
    break;

  default:
    jsonError('Unknown action.');
}
$conn->close();
?>
