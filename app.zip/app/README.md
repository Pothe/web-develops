# District Family Registry — PHP/MySQL/AJAX Web App

A full-featured web application for managing families and members across districts, built with PHP, MySQL, and AJAX.

---

## 📁 Project Structure

```
family-district-app/
├── index.php              # Main SPA application (all pages)
├── login.php              # Login page
├── logout.php             # Logout handler
├── database.sql           # Database schema + sample data
├── includes/
│   ├── config.php         # DB connection & constants
│   └── functions.php      # Auth, helpers, session
├── ajax/
│   ├── dashboard.php      # Dashboard stats AJAX
│   ├── districts.php      # District CRUD AJAX
│   ├── families.php       # Family CRUD AJAX
│   └── members.php        # Member CRUD AJAX
├── css/
│   └── style.css          # Full stylesheet
└── js/
    └── app.js             # AJAX helpers, Modal, Toast, Pagination
```

---

## ⚙️ Requirements

- PHP 7.4+ (8.x recommended)
- MySQL 5.7+ / MariaDB 10.3+
- Apache or Nginx with mod_rewrite
- A local server like XAMPP, WAMP, Laragon, or MAMP

---

## 🚀 Setup Instructions

### 1. Copy Files
Place the `family-district-app/` folder inside your web root:
- **XAMPP:** `C:/xampp/htdocs/family-district-app/`
- **WAMP:**  `C:/wamp/www/family-district-app/`
- **Linux:** `/var/www/html/family-district-app/`

### 2. Create Database
1. Open **phpMyAdmin** (http://localhost/phpmyadmin)
2. Click **New** → create database `family_district_db`
3. Select the database, click **Import**
4. Upload `database.sql` and click **Go**

OR run via command line:
```bash
mysql -u root -p < database.sql
```

### 3. Configure Database
Edit `includes/config.php` and update credentials:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // your MySQL username
define('DB_PASS', '');           // your MySQL password
define('DB_NAME', 'family_district_db');
```

### 4. Access the App
Open your browser:
```
http://localhost/app/
```

### 5. Login
| Field    | Value    |
|----------|----------|
| Username | `admin`  |
| Password | `password` |

> **Note:** The password in `database.sql` uses `password_hash()`. The sample hash corresponds to `password`. Change it after first login via direct DB update:
> ```sql
> UPDATE users SET password = '$2y$10$...' WHERE username = 'admin';
> ```
> Generate a new hash with: `php -r "echo password_hash('newpassword', PASSWORD_DEFAULT);"`

---

## ✨ Features

### Dashboard
- Live stats: total districts, families, members, active families
- Members by district (bar chart)
- Gender breakdown (visual)
- Recent families list

### Districts
- Add / Edit / Delete districts
- Each district shows family and member counts
- Search by name or code
- Paginated table

### Families
- Add / Edit / Delete families
- Filter by district and status
- Click a family to view all its members
- Add members directly from family detail view
- Paginated table

### Members
- Add / Edit / Delete members
- Filter by district, family, gender, status
- Age auto-calculated from date of birth
- Relationship roles: Head, Spouse, Child, Parent, Sibling
- Paginated table

### Reports
- Member distribution by district with visual bars
- Gender statistics with percentage breakdown

---

## 🛡️ Security Notes

- Passwords are hashed with `password_hash()` / `password_verify()`
- All input is sanitized and escaped before DB queries
- Session-based authentication with role support (admin / officer / viewer)
- Requires login for all pages

---

## 🔧 Customization

- **Add more roles:** Edit the `users.role` ENUM in `database.sql`
- **Add photo upload:** Add file upload handling to `ajax/members.php`
- **Export to CSV/Excel:** Add a `case 'export'` in each AJAX handler
- **Print/PDF report:** Add a print stylesheet or use a PDF library like TCPDF

---

## 📞 Support

This is a starter application. Feel free to extend it with:
- Export to CSV/PDF
- Photo uploads for members
- SMS/email notifications
- Multi-language support (Khmer + English)
- Map integration for district boundaries
