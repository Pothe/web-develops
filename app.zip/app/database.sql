-- ============================================
-- District Family Registry Database Schema
-- ============================================

CREATE DATABASE IF NOT EXISTS family_district_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE family_district_db;

-- Districts Table
CREATE TABLE IF NOT EXISTS districts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    code VARCHAR(20) UNIQUE NOT NULL,
    province VARCHAR(100),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Families Table
CREATE TABLE IF NOT EXISTS families (
    id INT AUTO_INCREMENT PRIMARY KEY,
    district_id INT NOT NULL,
    family_name VARCHAR(150) NOT NULL,
    family_code VARCHAR(30) UNIQUE NOT NULL,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    registration_date DATE,
    status ENUM('active','inactive') DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (district_id) REFERENCES districts(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Members Table
CREATE TABLE IF NOT EXISTS members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    family_id INT NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    gender ENUM('male','female','other') DEFAULT 'male',
    date_of_birth DATE,
    id_card VARCHAR(50),
    phone VARCHAR(20),
    email VARCHAR(100),
    occupation VARCHAR(100),
    education VARCHAR(100),
    relationship ENUM('head','spouse','child','parent','sibling','other') DEFAULT 'other',
    status ENUM('active','inactive','deceased','migrated') DEFAULT 'active',
    photo VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Users Table (Admin)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(150),
    email VARCHAR(100),
    role ENUM('admin','officer','viewer') DEFAULT 'viewer',
    district_id INT DEFAULT NULL,
    is_active TINYINT(1) DEFAULT 1,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (district_id) REFERENCES districts(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================
-- Sample Data
-- ============================================

INSERT INTO districts (name, code, province, description) VALUES
('Chamkar Mon', 'CMK', 'Phnom Penh', 'Chamkar Mon district in Phnom Penh'),
('Doun Penh', 'DNP', 'Phnom Penh', 'Doun Penh district in Phnom Penh'),
('7 Makara', 'SMK', 'Phnom Penh', '7 Makara district in Phnom Penh'),
('Tuol Kouk', 'TLK', 'Phnom Penh', 'Tuol Kouk district in Phnom Penh'),
('Sen Sok', 'SSK', 'Phnom Penh', 'Sen Sok district in Phnom Penh');

INSERT INTO families (district_id, family_name, family_code, address, phone, email, registration_date, status) VALUES
(1, 'Sok Family', 'FAM-CMK-001', 'St. 271, Phnom Penh', '012345678', 'sok@example.com', '2024-01-15', 'active'),
(1, 'Chan Family', 'FAM-CMK-002', 'St. 163, Phnom Penh', '012456789', 'chan@example.com', '2024-02-20', 'active'),
(2, 'Neak Family', 'FAM-DNP-001', 'St. 51, Phnom Penh', '012567890', 'neak@example.com', '2024-03-10', 'active'),
(3, 'Pich Family', 'FAM-SMK-001', 'St. 310, Phnom Penh', '012678901', 'pich@example.com', '2024-01-05', 'active');

INSERT INTO members (family_id, first_name, last_name, gender, date_of_birth, relationship, occupation, status) VALUES
(1, 'Sok', 'Dara', 'male', '1980-05-12', 'head', 'Teacher', 'active'),
(1, 'Sok', 'Sreymom', 'female', '1983-08-24', 'spouse', 'Nurse', 'active'),
(1, 'Sok', 'Visal', 'male', '2008-11-03', 'child', 'Student', 'active'),
(2, 'Chan', 'Sophea', 'male', '1975-02-18', 'head', 'Business Owner', 'active'),
(2, 'Chan', 'Ratha', 'female', '1978-07-30', 'spouse', 'Housewife', 'active'),
(3, 'Neak', 'Kosal', 'male', '1990-04-22', 'head', 'Engineer', 'active'),
(4, 'Pich', 'Socheat', 'male', '1965-12-10', 'head', 'Retired', 'active');

-- Default Admin User (password: admin123)
INSERT INTO users (username, password, full_name, email, role, is_active) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin@district.gov', 'admin', 1);
