<?php
require_once '../includes/functions.php';
requireLogin();
header('Content-Type: application/json');

$conn   = getConnection();
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

  case 'list':
    $page      = max(1, (int)($_GET['page'] ?? 1));
    $perPage   = 10;
    $search    = escape($conn, sanitize($_GET['search'] ?? ''));
    $family_id = (int)($_GET['family_id'] ?? 0);
    $district  = (int)($_GET['district_id'] ?? 0);
    $status    = escape($conn, sanitize($_GET['status'] ?? ''));
    $gender    = escape($conn, sanitize($_GET['gender'] ?? ''));

    $where = ['1=1'];
    if ($search) $where[] = "(m.first_name LIKE '%$search%' OR m.last_name LIKE '%$search%' OR m.id_card LIKE '%$search%' OR m.phone LIKE '%$search%')";
    if ($family_id) $where[] = "m.family_id=$family_id";
    if ($status)    $where[] = "m.status='$status'";
    if ($gender)    $where[] = "m.gender='$gender'";
    if ($district)  $where[] = "f.district_id=$district";
    $where = 'WHERE ' . implode(' AND ', $where);

    $total = $conn->query("SELECT COUNT(*) as c FROM members m JOIN families f ON m.family_id=f.id $where")->fetch_assoc()['c'];
    $pag   = paginate($total, $perPage, $page);

    $sql = "SELECT m.*, f.family_name, f.family_code, d.name AS district_name,
              TIMESTAMPDIFF(YEAR, m.date_of_birth, CURDATE()) AS age
            FROM members m
            JOIN families f ON m.family_id=f.id
            JOIN districts d ON f.district_id=d.id
            $where
            ORDER BY m.last_name, m.first_name
            LIMIT {$pag['per_page']} OFFSET {$pag['offset']}";
    $res = $conn->query($sql);
    $rows = [];
    while ($row = $res->fetch_assoc()) $rows[] = $row;
    jsonSuccess(['rows' => $rows, 'pagination' => $pag]);
    break;

  case 'get':
    $id  = (int)($_GET['id'] ?? 0);
    $sql = "SELECT m.*, f.family_name, TIMESTAMPDIFF(YEAR, m.date_of_birth, CURDATE()) AS age
            FROM members m JOIN families f ON m.family_id=f.id WHERE m.id=$id";
    $res = $conn->query($sql);
    if ($row = $res->fetch_assoc()) jsonSuccess($row);
    jsonError('Member not found', 404);
    break;

  case 'save':
    $id           = (int)($_POST['id'] ?? 0);
    $family_id    = (int)($_POST['family_id'] ?? 0);
    $first_name   = escape($conn, sanitize($_POST['first_name'] ?? ''));
    $last_name    = escape($conn, sanitize($_POST['last_name'] ?? ''));
    $gender       = escape($conn, sanitize($_POST['gender'] ?? 'male'));
    $dob          = escape($conn, sanitize($_POST['date_of_birth'] ?? ''));
    $id_card      = escape($conn, sanitize($_POST['id_card'] ?? ''));
    $phone        = escape($conn, sanitize($_POST['phone'] ?? ''));
    $email        = escape($conn, sanitize($_POST['email'] ?? ''));
    $occupation   = escape($conn, sanitize($_POST['occupation'] ?? ''));
    $education    = escape($conn, sanitize($_POST['education'] ?? ''));
    $relationship = escape($conn, sanitize($_POST['relationship'] ?? 'other'));
    $status       = escape($conn, sanitize($_POST['status'] ?? 'active'));
    $notes        = escape($conn, sanitize($_POST['notes'] ?? ''));

    if (!$first_name || !$last_name || !$family_id) jsonError('First name, last name and family are required.');
    $dob_val = $dob ? "'$dob'" : 'NULL';

    if ($id) {
      $ok = $conn->query("UPDATE members SET family_id=$family_id,first_name='$first_name',last_name='$last_name',gender='$gender',date_of_birth=$dob_val,id_card='$id_card',phone='$phone',email='$email',occupation='$occupation',education='$education',relationship='$relationship',status='$status',notes='$notes' WHERE id=$id");
      if ($ok) jsonSuccess(['id' => $id], 'Member updated.');
      jsonError($conn->error);
    } else {
      $ok = $conn->query("INSERT INTO members(family_id,first_name,last_name,gender,date_of_birth,id_card,phone,email,occupation,education,relationship,status,notes) VALUES($family_id,'$first_name','$last_name','$gender',$dob_val,'$id_card','$phone','$email','$occupation','$education','$relationship','$status','$notes')");
      if ($ok) jsonSuccess(['id' => $conn->insert_id], 'Member added.');
      jsonError($conn->error);
    }
    break;

  case 'delete':
    $id = (int)($_POST['id'] ?? 0);
    $ok = $conn->query("DELETE FROM members WHERE id=$id");
    if ($ok) jsonSuccess([], 'Member deleted.');
    jsonError($conn->error);
    break;

  case 'by_family':
    $fid = (int)($_GET['family_id'] ?? 0);
    $res = $conn->query("SELECT m.*, TIMESTAMPDIFF(YEAR, m.date_of_birth, CURDATE()) AS age FROM members m WHERE m.family_id=$fid ORDER BY FIELD(relationship,'head','spouse','child','parent','sibling','other'), m.last_name");
    $rows = [];
    while ($row = $res->fetch_assoc()) $rows[] = $row;
    jsonSuccess($rows);
    break;

  default:
    jsonError('Unknown action.', 400);
}
$conn->close();
?>
