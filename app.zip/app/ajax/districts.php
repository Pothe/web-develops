<?php
require_once '../includes/functions.php';
requireLogin();
header('Content-Type: application/json');

$conn   = getConnection();
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

  // ─── LIST ─────────────────────────────────────────────────────────────────
  case 'list':
    $page    = max(1, (int)($_GET['page'] ?? 1));
    $perPage = 10;
    $search  = escape($conn, sanitize($_GET['search'] ?? ''));
    $where   = $search ? "WHERE name LIKE '%$search%' OR code LIKE '%$search%'" : '';

    $total   = $conn->query("SELECT COUNT(*) as c FROM districts $where")->fetch_assoc()['c'];
    $pag     = paginate($total, $perPage, $page);
    $offset  = $pag['offset'];

    $sql = "SELECT d.*, 
              (SELECT COUNT(*) FROM families f WHERE f.district_id=d.id) AS family_count,
              (SELECT COUNT(*) FROM members m JOIN families f ON m.family_id=f.id WHERE f.district_id=d.id) AS member_count
            FROM districts d $where
            ORDER BY d.name ASC LIMIT $perPage OFFSET $offset";
    $res  = $conn->query($sql);
    $rows = [];
    while ($row = $res->fetch_assoc()) $rows[] = $row;
    jsonSuccess(['rows' => $rows, 'pagination' => $pag]);
    break;

  // ─── GET ONE ──────────────────────────────────────────────────────────────
  case 'get':
    $id  = (int)($_GET['id'] ?? 0);
    $res = $conn->query("SELECT * FROM districts WHERE id=$id");
    if ($row = $res->fetch_assoc()) jsonSuccess($row);
    jsonError('District not found', 404);
    break;

  // ─── SAVE (create / update) ───────────────────────────────────────────────
  case 'save':
    $id          = (int)($_POST['id'] ?? 0);
    $name        = escape($conn, sanitize($_POST['name'] ?? ''));
    $code        = strtoupper(escape($conn, sanitize($_POST['code'] ?? '')));
    $province    = escape($conn, sanitize($_POST['province'] ?? ''));
    $description = escape($conn, sanitize($_POST['description'] ?? ''));

    if (!$name || !$code) jsonError('Name and Code are required.');

    if ($id) {
      $ok = $conn->query("UPDATE districts SET name='$name',code='$code',province='$province',description='$description' WHERE id=$id");
      if ($ok) jsonSuccess(['id' => $id], 'District updated successfully.');
      jsonError($conn->error);
    } else {
      $ok = $conn->query("INSERT INTO districts(name,code,province,description) VALUES('$name','$code','$province','$description')");
      if ($ok) jsonSuccess(['id' => $conn->insert_id], 'District created successfully.');
      jsonError($conn->error);
    }
    break;

  // ─── DELETE ───────────────────────────────────────────────────────────────
  case 'delete':
    if (!isAdmin()) jsonError('Permission denied.', 403);
    $id = (int)($_POST['id'] ?? 0);
    $fc = $conn->query("SELECT COUNT(*) as c FROM families WHERE district_id=$id")->fetch_assoc()['c'];
    if ($fc > 0) jsonError('Cannot delete district with existing families.');
    $ok = $conn->query("DELETE FROM districts WHERE id=$id");
    if ($ok) jsonSuccess([], 'District deleted.');
    jsonError($conn->error);
    break;

  // ─── DROPDOWN ─────────────────────────────────────────────────────────────
  case 'dropdown':
    $res = $conn->query("SELECT id, name FROM districts ORDER BY name ASC");
    $rows = [];
    while ($row = $res->fetch_assoc()) $rows[] = $row;
    jsonSuccess($rows);
    break;

  default:
    jsonError('Unknown action.', 400);
}
$conn->close();
?>
